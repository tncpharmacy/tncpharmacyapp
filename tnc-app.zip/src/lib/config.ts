export const ENDPOINTS = {
  // 🔐 Auth
  LOGIN: "/user/login/",
  // REFRESH: "/user/token/refresh/", // 👉 agar backend se mile tab yaha add karna

  // 📍 Master Data
  GET_STATES: "/masterapp/state/",

  //Pharmacy Self(Pharmacy Admin)
  PHARMACY_SELF: "/pharmacy/pharmacies/", // get pharmacy self one
  PHARMACY_GET_PHARMACISTS: "/pharmacist/pharmacists/", // GET all
  PHARMACY_GET_PHARMACIST_BY_ID: (id: number | string) =>
    `/pharmacist/pharmacists/${id}/`, // GET one
  PHARMACY_CREATE_PHARMACIST: "/pharmacist/register/", // POST
  PHARMACY_UPDATE_PHARMACIST: (id: number | string) =>
    `/pharmacist/pharmacists/${id}/`, // PATCH
  PHARMACY_DELETE_PHARMACIST: (id: number | string) =>
    `/pharmacist/pharmacists/${id}/`, // DELETE

  //Pharmacist Self(Pharmacist Admin)
  PHARMACIST_SELF: "/pharmacist/self/", // get pharmacist self one

  // 🏥 Pharmacies (Superadmin side)
  GET_PHARMACY_LIST: "/pharmacy/list/", // general list
  GET_PHARMACIES: "/pharmacy/superadmin/pharmacies/", // GET all
  GET_PHARMACY_BY_ID: (id: number | string) =>
    `/pharmacy/superadmin/pharmacies/${id}/`, // GET one
  CREATE_PHARMACY: "/pharmacy/register/", // POST
  UPDATE_PHARMACY: (id: number | string) =>
    `/pharmacy/superadmin/pharmacies/${id}/`, // PATCH
  DELETE_PHARMACY: (id: number | string) =>
    `/pharmacy/superadmin/pharmacies/${id}/`, // DELETE

  // 👨‍⚕️ Pharmacists
  GET_PHARMACISTS: "/pharmacist/pharmacists/", // GET all
  GET_PHARMACIST_BY_ID: (id: number | string) =>
    `/pharmacist/pharmacists/${id}/`, // GET one
  CREATE_PHARMACIST: "/pharmacist/register/", // POST
  UPDATE_PHARMACIST: (id: number | string) => `/pharmacist/pharmacists/${id}/`, // PATCH
  DELETE_PHARMACIST: (id: number | string) => `/pharmacist/pharmacists/${id}/`, // DELETE
};
