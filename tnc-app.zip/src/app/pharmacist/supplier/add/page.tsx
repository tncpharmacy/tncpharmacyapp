"use client";

import SupplierForm from "@/app/components/Form/SupplierForm";

export default function AddPharmacy() {
  return <SupplierForm />;
}
