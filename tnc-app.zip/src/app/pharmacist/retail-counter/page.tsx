"use client";

import "../css/pharmacy-style.css";
import SideNav from "@/app/pharmacist/components/SideNav/page";
import Header from "@/app/pharmacist/components/Header/page";
import { useCallback, useEffect, useState } from "react";
import { useAppDispatch, useAppSelector } from "@/lib/hooks";
import {
  getProductByGenericId,
  getProductList,
} from "@/lib/features/medicineSlice/medicineSlice";
import { Medicine } from "@/types/medicine";
import SingleSelectDropdown, {
  OptionType,
} from "@/app/components/Input/SingleSelectDropdown";
import GenericOptionsModal from "@/app/components/RetailCounterModal/GenericOptionsModal";
import AddBillingItemModal from "@/app/components/RetailCounterModal/AddBillingItemModal";

export default function RetailCounter() {
  const despatch = useAppDispatch();
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [cart, setCart] = useState<any[]>([]);

  // ✅ Redux State Selector: genericAlternatives और loading स्टेट यहाँ से आ रहे हैं।
  const {
    medicines: productList,
    genericAlternatives: productListByGeneric,
    loading,
  } = useAppSelector((state) => state.medicine);

  // Component States
  const [selectedMedicine, setSelectedMedicine] = useState<Medicine | null>(
    null
  );
  const [isModalOpen, setIsModalOpen] = useState(false);
  // ✅ Modal को खोलने के लिए आवश्यक State
  const [selectedGenericId, setSelectedGenericId] = useState<number | null>(
    null
  );
  const [isQtyModalOpen, setIsQtyModalOpen] = useState(false); // ✅ New Modal State
  const [itemToConfirm, setItemToConfirm] = useState<Medicine | null>(null); // ✅ New State for selected item

  // Initial product list fetch
  useEffect(() => {
    despatch(getProductList());
  }, [despatch]);

  // Dropdown Change Handler: Dispatch API call and set the active ID
  const handleSelectMedicine = (selectedOption: OptionType | null) => {
    if (selectedOption) {
      const foundMedicine = productList.find(
        (m) => m.id === selectedOption.value
      );
      setSelectedMedicine(foundMedicine || null);
      setIsModalOpen(true);
      const genericId = selectedOption.value;
      despatch(getProductByGenericId(genericId));
      setSelectedGenericId(genericId);
    } else {
      setSelectedMedicine(null);
      setSelectedGenericId(null);
      setIsModalOpen(false);
    }
  };

  // New Handler: Go Back from Qty Modal to Generic Modal
  const handleBackToGeneric = () => {
    setIsQtyModalOpen(false);
    setIsModalOpen(true);
  };

  // Update handleCloseQtyModal: Only closes this modal
  const handleCloseQtyModal = () => {
    setIsQtyModalOpen(false);
    setItemToConfirm(null);
  };

  // Update handleSelectAlternative (Must call handleCloseQtyModal to close first modal)
  const handleSelectAlternative = (item: Medicine) => {
    setIsModalOpen(false);
    setItemToConfirm(item);
    setIsQtyModalOpen(true);
  };

  // Modal Close Handler: Reset all related states
  const handleCloseModal = useCallback(() => {
    setIsModalOpen(false);
    setSelectedGenericId(null);
    setSelectedMedicine(null); // Dropdown clear करने के लिए
  }, []);

  const handleRemoveItem = (itemId: number) => {
    setCart((prevCart) => {
      return prevCart.filter((item) => item.id !== itemId);
    });
  };

  // Final Add to Cart handler (From Qty Modal)
  const handleFinalAddToCart = (
    item: Medicine,
    qty: number,
    doseForm: string,
    remarks: string
  ) => {
    const itemToAdd = {
      ...item,
      dose_form: doseForm,
      qty: qty,
      remarks: remarks,
      price: (item.MRP || 0) * qty, // ✅ Price calculation
    };
    setCart((prevCart) => {
      // ... (Existing cart check/update logic can go here, but for simplicity, we add it directly)
      return [...prevCart, itemToAdd];
    });
    handleCloseQtyModal(); // Modal बंद करें
  };

  useEffect(() => {
    if (
      selectedGenericId !== null &&
      productListByGeneric.length > 0 &&
      !loading
    ) {
      setIsModalOpen(true);
    }
  }, [loading, productListByGeneric.length, selectedGenericId]);

  return (
    <>
      <Header />
      <div className="body_wrap">
        <SideNav />
        <div className="body_right p-4">
          <div className="container-fluid retail-counter">
            <h4 className="mb-4">
              <i className="bi bi-receipt-cutoff me-2"></i>
              Retail Counter
            </h4>

            {/* Medicine Search Section */}
            <div className="card shadow-sm mb-4">
              <div className="card-body">
                <div className="row g-3 align-items-end">
                  <div className="col-md-8">
                    <div className="txt_col">
                      <SingleSelectDropdown
                        medicines={productList}
                        selected={
                          selectedMedicine
                            ? {
                                label: selectedMedicine.medicine_name,
                                value: selectedMedicine.id,
                              }
                            : null
                        }
                        onChange={handleSelectMedicine}
                      />
                    </div>
                  </div>
                  <div className="col-md-4 text-end">
                    <div className="txt_col">
                      <button
                        className="btn-style1"
                        // onClick={handleExportToExcel}
                        // disabled={selectedMedicines.length === 0}
                      >
                        <i className="bi bi-upload"></i> Upload Prescription
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Bill Table */}
            <div className="card shadow-sm mb-4">
              <div className="card-body">
                <h6 className="mb-3">
                  <i className="bi bi-cart-check me-2"></i>Billing Items
                </h6>
                <div className="table-responsive">
                  <table className="table table-bordered align-middle">
                    <thead className="table-light">
                      <tr>
                        <th>Medicine</th>
                        <th>Dose Form</th>
                        <th>Qty</th>
                        <th>Price (₹)</th>
                        <th>Subtotal (₹)</th>
                        <th>Remarks</th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                      {cart.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="text-center text-muted">
                            No items added yet
                          </td>
                        </tr>
                      ) : (
                        cart.map((item, index) => (
                          <tr key={index}>
                            <td>{item.medicine_name}</td>
                            <td>{item.dose_form}</td>
                            <td>{item.qty}</td>
                            <td>{item.price}</td>
                            <td>{item.qty * item.price}</td>
                            <td>{item.remarks}</td>
                            <td>
                              <button
                                className="btn btn-sm btn-danger"
                                onClick={() => handleRemoveItem(item.id)}
                              >
                                <i className="bi bi-trash"></i>
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>

                {/* Total and Actions */}
                <div className="d-flex justify-content-between align-items-center mt-3">
                  <h5 className="fw-bold mb-0">
                    Total: ₹
                    {cart.reduce((acc, item) => acc + item.price * item.qty, 0)}
                  </h5>
                  <button className="btn btn-primary px-4">
                    <i className="bi bi-file-earmark-text me-1"></i>
                    Generate Bill
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* ✅ Generic Selection Modal */}
      <GenericOptionsModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        productListByGeneric={productListByGeneric}
        loading={loading}
        onAddToCart={handleSelectAlternative} // 🚨 Prop name changed
      />

      {/* 2. ✅ New Qty/Dose Form Modal */}
      <AddBillingItemModal
        isOpen={isQtyModalOpen}
        onClose={handleCloseQtyModal}
        item={itemToConfirm}
        onConfirmAdd={handleFinalAddToCart}
        onBack={handleBackToGeneric}
      />
    </>
  );
}
