import HomePage from "./user/home/page";

export default function Home() {
  return <HomePage />;
}
