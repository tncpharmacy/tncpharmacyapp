"use client";

import PharmacistForm from "@/app/components/Form/PharmacistForm";

export default function AddPharmacist() {
  return <PharmacistForm />;
}
