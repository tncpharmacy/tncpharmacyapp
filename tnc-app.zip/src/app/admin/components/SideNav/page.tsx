"use client";

import { SetStateAction, useState } from "react";
import Link from "next/link";

export default function SideNav() {
  const [openMenu, setOpenMenu] = useState<string | null>(null);

  const toggleMenu = (menu: string) => {
    setOpenMenu(openMenu === menu ? null : menu);
  };

  return (
    <div className="side_menu">
      <span className="btnsidemenu cursor-pointer text-xl">
        <i className="bi bi-arrow-left"></i>
      </span>

      <ul className="side_menu-list">
        <li>
          <Link href="/admin-dashboard" className="link">
            <i className="bi bi-activity"></i> Dashboard
          </Link>
        </li>
        <hr />
        {/* <li className={`${openMenu === "order" ? "active" : ""}`}>
          <div onClick={() => toggleMenu("order")} className="link arrow">
            <i className="bi bi-cart-plus-fill"></i> Order
          </div>

          {openMenu === "order" && (
            <ul className="submenu">
              <li><Link href="#">New Order</Link></li>
              <li><Link href="#">Order Shipped</Link></li>
              <li><Link href="#">Return Request</Link></li>
            </ul>
          )}
        </li>
<hr />
        <li>
          <div onClick={() => toggleMenu("medicine")} className="link arrow">
            <i className="bi bi-capsule-pill"></i> Medicine
          </div>
          {openMenu === "medicine" && (
            <ul className="submenu">
              <li><Link href="#">Medicine Stocks</Link></li>
              <li><Link href="#">Add Medicine</Link></li>
            </ul>
          )}
        </li> */}
        <li>
          <Link href="/orders" className="link">
            <i className="bi bi-cart-plus-fill"></i> Order
          </Link>
        </li>
        <hr />
        <li>
          <Link href="/medicines" className="link">
            <i className="bi bi-capsule"></i> Medicine
          </Link>
        </li>
        <hr />
        <li>
          <Link href="/doctors" className="link">
            <i className="bi bi-person-plus"></i> Doctors
          </Link>
        </li>
        <hr />
        <li>
          <Link href="/pharmacy" className="link">
            <i className="bi bi-shop-window"></i> Pharmacy
          </Link>
        </li>
        <hr />
        <li>
          <Link href="/pharmacist" className="link">
            <i className="bi bi-people"></i> Pharmacist
          </Link>
        </li>
        <hr />
        <li>
          <Link href="/suppliers" className="link">
            <i className="bi bi-shop-window"></i> Supplier
          </Link>
        </li>
        <hr />
        <li>
          <div onClick={() => toggleMenu("visitors")} className="link arrow">
            <i className="bi bi-mouse2-fill"></i> Visitors
          </div>
          {openMenu === "visitors" && (
            <ul className="submenu">
              <li>
                <Link href="#">Visitor List</Link>
              </li>
            </ul>
          )}
        </li>
        <hr />
        <li>
          <div onClick={() => toggleMenu("profile")} className="link arrow">
            <i className="bi bi-person-lines-fill"></i> Profile
          </div>
          {openMenu === "profile" && (
            <ul className="submenu">
              <li>
                <Link href="#">Profile Details</Link>
              </li>
            </ul>
          )}
        </li>
        <hr />
        <li>
          <div onClick={() => toggleMenu("product")} className="link arrow">
            <i className="bi bi-capsule-pill"></i> Product Master
          </div>
          {openMenu === "product" && (
            <ul className="submenu">
              <li>
                <Link href="/categories">Medicine Category</Link>
              </li>
              <li>
                <Link href="/brands">Medicine Brand</Link>
              </li>
              <li>
                <Link href="/units">Medicine Unit</Link>
              </li>
              <li>
                <Link href="/manufacturers">Medicine Manufacturer</Link>
              </li>
              <li>
                <Link href="/variants">Medicine Variant</Link>
              </li>
              <li>
                <Link href="/strengths">Medicine Strength</Link>
              </li>
            </ul>
          )}
        </li>
        <hr />
        <li>
          <div onClick={() => toggleMenu("settings")} className="link arrow">
            <i className="bi bi-gear-wide-connected"></i> Settings
          </div>
          {openMenu === "settings" && (
            <ul className="submenu">
              <li>
                <Link href="#">Reset Password</Link>
              </li>
            </ul>
          )}
        </li>
        <hr />
        <li>
          <div onClick={() => toggleMenu("report")} className="link arrow">
            <i className="bi bi-database-fill-add"></i> Report
          </div>
          {openMenu === "report" && (
            <ul className="submenu">
              <li>
                <Link href="#">Booking Report</Link>
              </li>
            </ul>
          )}
        </li>
      </ul>
    </div>
  );
}
