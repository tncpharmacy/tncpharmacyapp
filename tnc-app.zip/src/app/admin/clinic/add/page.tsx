"use client";

import ClinicForm from "@/app/components/Form/ClinicForm";

export default function AddClinic() {
  return <ClinicForm />;
}
