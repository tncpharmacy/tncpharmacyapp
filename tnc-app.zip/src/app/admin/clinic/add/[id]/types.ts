export interface IdPageProps {
  params: { id: string }; // हमेशा string के रूप में आएगा
}
