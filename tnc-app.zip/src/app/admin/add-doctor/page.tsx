"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Button, Modal } from "react-bootstrap";
import "../css/admin-style.css";
import SideNav from "@/app/admin/components/SideNav/page";
import Header from "@/app/admin/components/Header/page";
import { useRouter } from "next/navigation";
import ProfileImageUpload from "@/app/components/profile-image/ProfileImageUpload";
import Input from "@/app/components/Input/Input";
import MultiSelect from "@/app/components/MultiSelectDropdown/MultiSelectDropdown";

export default function AddDoctor() {
  const router = useRouter();
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [selectedQualification, setSelectedQualification] = useState<string[]>(
    []
  );
  const [formData, setFormData] = useState<string>("");

  const doctorOptions = [
    {
      label: "MBBS – Bachelor of Medicine, Bachelor of Surgery",
      value: "MBBS",
    },
    { label: "BDS – Bachelor of Dental Surgery", value: "BDS" },
    {
      label: "BAMS – Bachelor of Ayurvedic Medicine and Surgery",
      value: "BAMS",
    },
    {
      label: "BHMS – Bachelor of Homeopathic Medicine and Surgery",
      value: "BHMS",
    },
    { label: "BUMS – Bachelor of Unani Medicine and Surgery", value: "BUMS" },
    {
      label: "BNYS – Bachelor of Naturopathy and Yogic Sciences",
      value: "BNYS",
    },
    { label: "BSMS – Bachelor of Siddha Medicine and Surgery", value: "BSMS" },
  ];

  const clinicOptions = [
    {
      label: "Primacare Superspeciality Hospitals",
      value: "Primacare Superspeciality Hospitals",
    },
    { label: "Renacare Dialysis Center", value: "Renacare Dialysis Center" },

    { label: "IIG Clinic", value: "IIG Clinic" },
    {
      label: "AMS Clinic",
      value: "AMS Clinic",
    },
    { label: "BHYM Clinic", value: "BHYM Clinic" },
  ];

  return (
    <>
      <Header />
      <div className="body_wrap">
        <SideNav />
        <div className="body_right">
          <div className="body_content">
            <div className="pageTitle">
              <i className="bi bi-person-add"></i> Add Doctor
              <button
                onClick={() => router.back()}
                className="btn-style2 float-end pe-4 ps-4"
              >
                ← Back
              </button>
            </div>
            <div className="main_content">
              <div className="col-sm-12">
                <div className="row">
                  <Input
                    label="Doctor Name"
                    name="doctorName"
                    // value={doctorName}
                    placeholder="Enter Doctor name"
                    onChange={(e) => setFormData(e.target.value)}
                    required
                    // error={error}
                  />
                  <div className="col-md-4">
                    <div className="txt_col">
                      <span className="lbl1">Clinic</span>
                      <MultiSelect
                        options={clinicOptions}
                        selected={selectedQualification}
                        onChange={setSelectedQualification}
                        placeholder="--Select--"
                        itemName="Clinic"
                      />
                    </div>
                  </div>
                  <div className="col-md-4">
                    <div className="txt_col">
                      <span className="lbl1">Date of Birth</span>
                      <input
                        type="text"
                        className="txt1"
                        id=""
                        placeholder="Enter Date of Birth"
                      />
                    </div>
                  </div>
                  <div className="clearfix"></div>
                  <div className="col-md-4">
                    <div className="txt_col">
                      <span className="lbl1">Gender</span>
                      <select className="txt1">
                        <option>-Select-</option>
                        <option>Male</option>
                        <option>Female</option>
                      </select>
                    </div>
                  </div>
                  <div className="col-md-4">
                    <div className="txt_col">
                      <span className="lbl1">Mobile No</span>
                      <input
                        type="text"
                        className="txt1"
                        id=""
                        placeholder="Enter contact number"
                      />
                    </div>
                  </div>
                  <div className="col-md-4">
                    <div className="txt_col">
                      <span className="lbl1">Email Id.</span>
                      <input
                        type="text"
                        className="txt1"
                        id=""
                        placeholder="Enter email address"
                      />
                    </div>
                  </div>
                  <div className="clearfix"></div>
                  <div className="col-md-4">
                    <div className="txt_col">
                      <span className="lbl1">Whatsapp No</span>
                      <input
                        type="text"
                        className="txt1"
                        id=""
                        placeholder="Enter contact number"
                      />
                    </div>
                  </div>
                  <div className="col-md-4">
                    <div className="txt_col">
                      <span className="lbl1">Qualification</span>
                      <MultiSelect
                        options={doctorOptions}
                        selected={selectedItems}
                        onChange={setSelectedItems}
                        placeholder="--Select--"
                        itemName="Qualification"
                      />
                    </div>
                  </div>
                  <div className="col-md-4">
                    <div className="txt_col">
                      <span className="lbl1">Speciality</span>
                      <select className="txt1">
                        <option>--Select--</option>
                        <option>Cardiology</option>
                        <option>General Surgery</option>
                        <option>Neurology</option>
                        <option>Urology</option>
                      </select>
                    </div>
                  </div>
                  <div className="clearfix"></div>
                  <div className="clearfix"></div>
                  <div className="col-md-4">
                    <div className="txt_col">
                      <span className="lbl1">Experiance (Year)</span>
                      <input
                        type="text"
                        className="txt1"
                        id=""
                        placeholder="Enter Year of Experiance"
                      />
                    </div>
                  </div>
                  <div className="col-md-4">
                    <div className="txt_col">
                      <span className="lbl1">Registration (Licence) No.</span>
                      <input
                        type="text"
                        className="txt1"
                        id=""
                        placeholder="Enter licence number"
                      />
                    </div>
                  </div>
                  <div className="col-md-4">
                    <div className="txt_col">
                      <span className="lbl1">Registration Council</span>
                      <input
                        type="text"
                        className="txt1"
                        id=""
                        placeholder="Enter Registration Council"
                      />
                    </div>
                  </div>
                  <div className="col-md-4">
                    <div className="txt_col">
                      <span className="lbl1">Registration Year</span>
                      <input
                        type="text"
                        className="txt1"
                        id=""
                        placeholder="Enter Registration Year"
                      />
                    </div>
                  </div>
                  <div className="col-md-4">
                    <div className="txt_col">
                      <span className="lbl1">Valid Upto</span>
                      <input
                        type="text"
                        className="txt1"
                        id=""
                        placeholder="Enter Registration Expiry Date"
                      />
                    </div>
                  </div>
                  <div className="col-md-4">
                    <div className="txt_col">
                      <span className="lbl1">Doctor Address</span>
                      <input
                        type="text"
                        className="txt1"
                        id=""
                        placeholder="Enter Registration Expiry Date"
                      />
                    </div>
                  </div>
                  <div className="clearfix"></div>
                  <div className="col-md-4">
                    <div className="txt_col">
                      <span className="lbl1">Consultation Fee</span>
                      <input
                        type="text"
                        className="txt1"
                        id=""
                        placeholder="Enter consultation fee"
                      />
                    </div>
                  </div>
                  <div className="col-md-4">
                    <div className="txt_col">
                      <span className="lbl1">Video Consultation Fee</span>
                      <input
                        type="text"
                        className="txt1"
                        id=""
                        placeholder="Enter consultation fee"
                      />
                    </div>
                  </div>
                  <div className="col-md-4">
                    <div className="txt_col">
                      <span className="lbl1">
                        Audio (Mobile) Consultation Fee
                      </span>
                      <input
                        type="text"
                        className="txt1"
                        id=""
                        placeholder="Enter consultation fee"
                      />
                    </div>
                  </div>
                  <div className="clearfix"></div>
                  <div className="col-md-4 d-flex justify-content-center">
                    <div className="txt_col border p-4">
                      <ProfileImageUpload />
                    </div>
                  </div>
                  <div className="col-md-8">
                    <div className="txt_col">
                      <span className="lbl1">Professional Summary</span>
                      <textarea
                        className="txt1 h-50"
                        id=""
                        rows={10}
                        placeholder="Enter professional summary"
                      ></textarea>
                    </div>
                  </div>
                  <div className="clearfix"></div>
                  <div className="col-md-12">
                    <div className="txt_col">
                      <span className="lbl1">Document Upload</span>
                      <input
                        type="file"
                        className="txt1"
                        id=""
                        placeholder="Enter Registration Expiry Date"
                      />
                    </div>
                  </div>
                  <div className="col-md-4">
                    <button className="btn-style2">Submit</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
