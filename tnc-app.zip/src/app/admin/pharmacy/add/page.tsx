"use client";

import PharmacyForm from "@/app/components/Form/PharmacyForm";

export default function AddPharmacy() {
  return <PharmacyForm />;
}
