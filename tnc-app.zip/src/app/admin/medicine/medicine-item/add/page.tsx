"use client";

import MedicineForm from "@/app/components/Form/MedicineForm";

export default function AddMedicine() {
  return <MedicineForm />;
}
