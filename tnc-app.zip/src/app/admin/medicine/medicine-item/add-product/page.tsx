"use client";

import OtherMedicineForm from "@/app/components/Form/OtherMedicineForm";

export default function AddMedicine() {
  return <OtherMedicineForm />;
}
