"use client";

import PharmacistByPharmacyForm from "@/app/components/Form/PharmacistByPharmacyForm";

export default function AddPharmacist() {
  return <PharmacistByPharmacyForm />;
}
