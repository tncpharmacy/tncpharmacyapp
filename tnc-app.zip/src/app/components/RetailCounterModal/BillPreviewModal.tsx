"use client";
import { useAppDispatch } from "@/lib/hooks";
import { useEffect, useRef, useState } from "react";
import { Image, Modal } from "react-bootstrap";

// Mock style object
const styles = {
  modalContentWrapper: "p-4 border rounded",
  customerInfo: "mb-4 p-3 bg-light rounded",
};

interface CartItem {
  id: number;
  medicine_name: string;
  generic_name?: string;
  GenericName?: string;
  pack_size?: string;
  qty: number;
  price: number;
  dose_form: string;
  Disc: number;
  remarks: string;
}

interface BillPreviewModalProps {
  show: boolean;
  onClose: () => void;
  cart: CartItem[] | undefined;
  customerName: string;
  mobile: string;
  pharmacy_id?: number;
}

const BillPreviewModal: React.FC<BillPreviewModalProps> = ({
  show,
  onClose,
  cart,
  customerName,
  mobile,
}) => {
  const printRef = useRef<HTMLDivElement>(null);
  const dispatch = useAppDispatch();

  const [language, setLanguage] = useState("en");
  const [translatedCart, setTranslatedCart] = useState<CartItem[]>(cart || []);
  const [isTranslating, setIsTranslating] = useState(false);
  const [apiError, setApiError] = useState<string | null>(null);

  useEffect(() => {
    if (!show) return;
    setTranslatedCart(cart || []);
    setLanguage("en");
    setApiError(null);
  }, [show, cart]);

  // 🔵 PRINT BILL — ONLY BILL SECTION
  const handlePrintBill = () => {
    const bill = printRef.current;
    if (!bill) return;

    const billHtml = bill.querySelector(".bill-section")?.innerHTML || "";

    const win = window.open("", "_blank", "width=800,height=1000");
    if (!win) return; // <-- FIX

    win.document.write(`
    <html>
      <head>
        <title>Bill</title>
        <style>
          body { font-family: Arial; padding: 10px; }
          table, th, td { border:1px solid #000; border-collapse: collapse; }
          th, td { padding:6px; }
          @page { size: A4; margin:10mm; }
        </style>
      </head>
      <body>
        ${billHtml}
      </body>
    </html>
  `);

    win.document.close();
    win.print();
    win.close();
  };

  // 🟡 PRINT LABEL — ONLY CARD SECTION
  const handlePrintLabel = () => {
    const bill = printRef.current;
    if (!bill) return;

    const cardHtml = bill.querySelector(".card-section")?.innerHTML || "";

    const win = window.open("", "_blank", "width=400,height=600");
    if (!win) return;

    win.document.write(`
    <html>
      <head>
        <title>Label</title>
        <style>
          * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
          }

          body {
            margin: 0;
            padding: 0;
            font-family: Arial;
          }

          /* ---------------- REAL LABEL SIZE ---------------- */
          .print-card {
            width: 60mm !important;
            height: 50mm !important;
            padding: 3mm;
            border: 1px solid #000;
            overflow: hidden !important;

            display: flex;
            flex-direction: column;
            justify-content: space-between;

            page-break-after: always;
          }

          .print-card p {
            font-size: 10px;
            line-height: 1.1;
            margin-bottom: 2px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
          }

          .print-card strong {
            font-size: 11px;
          }

          /* ---------------- FIXED PRINT PAGE SIZE ---------------- */
          @page {
            size: 60mm 50mm;
            margin: 0;
          }
        </style>
      </head>

      <body>
        ${cardHtml}
      </body>
    </html>
  `);

    win.document.close();
    setTimeout(() => {
      win.print();
      win.close();
    }, 300);
  };

  const grandTotal = (cart || []).reduce((acc, item) => {
    const total = item.qty * item.price;
    const discountAmount = item.Disc ? (total * item.Disc) / 100 : 0;
    return acc + (total - discountAmount);
  }, 0);

  if (!show) return null;

  return (
    <Modal show={show} onHide={onClose} size="lg" centered>
      <Modal.Header closeButton className="border-0 pb-0">
        <Modal.Title className="fw-semibold text-primary">
          🧾 Bill Preview
        </Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <div className={styles.modalContentWrapper} ref={printRef}>
          {/* ---------------- BILL SECTION (ONLY FOR PRINT BILL) ---------------- */}
          <div className="bill-section">
            {/* Header */}
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "flex-start",
                marginBottom: "20px",
                borderBottom: "2px solid #007bff",
                paddingBottom: "8px",
              }}
            >
              <div
                style={{ display: "flex", alignItems: "center", gap: "10px" }}
              >
                <Image
                  src="/images/logo.png"
                  alt="TnC Pharmacy"
                  style={{ height: 90, width: 200, objectFit: "contain" }}
                />
              </div>

              <div
                style={{
                  textAlign: "right",
                  fontSize: "12px",
                  color: "#333",
                  lineHeight: "1.4",
                  maxWidth: "220px",
                }}
              >
                <strong style={{ fontSize: "13px", color: "#007bff" }}>
                  TnC Pharmacy
                </strong>
                <br />
                123 Main Street, City - 000000 <br />
                Ph: +91-9999999999 <br />
                Email: support@tncpharmacy.in
              </div>
            </div>

            {/* Customer Info */}
            <div className={styles.customerInfo}>
              <div className="d-flex justify-content-between">
                <div>
                  <strong>Customer Name:</strong> {customerName || "-"}
                </div>
                <div>
                  <strong>Mobile No.:</strong> {mobile || "-"}
                </div>
              </div>
            </div>

            {/* Billing Table */}
            <h3
              style={{
                fontSize: "16px",
                fontWeight: "700",
                color: "#007bff",
                marginBottom: "10px",
              }}
            >
              Billing Summary
            </h3>

            <table
              className="table table-bordered text-center align-middle"
              style={{ border: "1px solid #000", width: "100%" }}
            >
              <thead className="table-light">
                <tr>
                  <th>Medicine</th>
                  <th>Qty</th>
                  <th>MRP (₹)</th>
                  <th>Discount (%)</th>
                  <th>Subtotal (₹)</th>
                </tr>
              </thead>
              <tbody>
                {translatedCart.map((item, idx) => {
                  const total = item.qty * item.price;
                  const discountAmount = item.Disc
                    ? (total * item.Disc) / 100
                    : 0;
                  const subtotal = total - discountAmount;

                  return (
                    <tr key={idx}>
                      <td>{item.medicine_name}</td>
                      <td>
                        {item.pack_size
                          ? `${item.pack_size} × ${item.qty}`
                          : item.qty}
                      </td>
                      <td>{item.price}</td>
                      <td>{item.Disc}</td>
                      <td>{subtotal.toFixed(2)}</td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot>
                <tr style={{ backgroundColor: "#f8f9fa" }}>
                  <th colSpan={4} className="text-end">
                    Grand Total
                  </th>
                  <th style={{ color: "#007bff" }}>{grandTotal.toFixed(2)}</th>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* PAGE BREAK */}
          <div style={{ pageBreakBefore: "always" }}></div>

          {/* ---------------- CARD SECTION (ONLY FOR PRINT LABEL) ---------------- */}
          <div className="card-section" style={{ marginTop: "25px" }}>
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                flexWrap: "wrap",
                gap: "20px",
                width: "100%",
              }}
            >
              {translatedCart.map((item, idx) => (
                <div
                  key={idx}
                  className="print-card"
                  style={{
                    width: "60mm",
                    height: "50mm",
                    border: "1px solid #333",
                    padding: "6px",
                    background: "#fff",
                    overflow: "hidden",

                    // 🟡 MUST → Har card new page
                    pageBreakAfter: "always",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                    }}
                  >
                    <Image
                      src="/images/logo-bw-h.png"
                      alt=""
                      width="100"
                      height="35"
                    />

                    <p style={{ fontSize: "12px" }}>
                      <strong>Date:</strong>{" "}
                      {new Date().toLocaleDateString("en-GB", {
                        day: "2-digit",
                        month: "short",
                        year: "numeric",
                      })}
                    </p>
                  </div>

                  <hr />

                  <p>
                    <strong>Patient:</strong> {customerName}
                  </p>
                  <p>
                    <strong>Medicine:</strong> {item.medicine_name}
                  </p>
                  <p>
                    <strong>Dose:</strong> {item.dose_form}
                  </p>
                  <p>
                    <strong>Instruction:</strong> {item.remarks}
                  </p>
                  <p>
                    <strong>Qty:</strong>{" "}
                    {item.pack_size
                      ? `${item.pack_size} × ${item.qty}`
                      : item.qty}
                  </p>

                  <div
                    style={{
                      marginTop: "10px",
                      borderTop: "1px solid #ccc",
                      paddingTop: "5px",
                      textAlign: "center",
                    }}
                  >
                    <p style={{ fontSize: "12px", marginBottom: "4px" }}>
                      www.tncpharmacy.in
                    </p>
                    <p style={{ fontSize: "12px", marginBottom: "4px" }}>
                      24×7 Support: 9578458754
                    </p>
                    <p
                      style={{
                        fontSize: "10px",
                        fontStyle: "italic",
                        margin: "0",
                      }}
                    >
                      Get Well Soon
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Modal.Body>

      {/* ---------------- FOOTER ---------------- */}
      <Modal.Footer className="border-0 pt-0">
        <button className="btn btn-outline-secondary" onClick={onClose}>
          Close
        </button>

        {/* 🟡 PRINT LABEL BUTTON */}
        <button className="btn btn-warning" onClick={handlePrintLabel}>
          Print Label
        </button>

        {/* 🔵 PRINT BILL BUTTON */}
        <button className="btn btn-primary" onClick={handlePrintBill}>
          Print Bill
        </button>
      </Modal.Footer>
    </Modal>
  );
};

export default BillPreviewModal;
