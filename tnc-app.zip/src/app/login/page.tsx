"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import "../styles/style-login.css";
import Link from "next/link";

export default function LoginForm() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const router = useRouter();

  const handleLogin = () => {
    if (email === "1" && password === "1") {
      router.push(`/admin-dashboard`);
    } else if (email === "2" && password === "2") {
      router.push(`/doctor/doctor-dashboard`);
    } else if (email === "3" && password === "3") {
      router.push(`/pharmacy/pharmacy-dashboard`);
    } else if (email === "4" && password === "4") {
      router.push(`/pharmacist/pharmacist-dashboard`);
    } else {
      alert("Invalid credentials!");
    }
  };

  return (
    <>
      <div className="container-fluid">
        <div className="row">
          <div className="col-xl-7 col-lg-6 col-md-12 order-last order-xl-0 bg_img">
            <div className="text-center">
              <div className="logologin">
                <img src="images/logo.png" alt="" />
              </div>
              <div className="info">
                <div className="animated_text">
                  <h1>TnC Pharmacy</h1>
                </div>
                <p>For Admin</p>
              </div>
              <p className="copyright">
                © 2025 TnC Pharmacy | All Rights Reserved
              </p>
            </div>
          </div>
          <div className="col-xl-5 col-lg-6 col-md-12 d-flex align-items-center justify-content-center">
            <div className="login_form">
              <div className="row_login">
                <span className="lbl1">Login ID</span>
                <input
                  type="text"
                  className="txt1"
                  placeholder="Email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
              <div className="row_login">
                <span className="lbl1">Password</span>
                <input
                  type="password"
                  className="txt1"
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>

              <button
                onClick={handleLogin}
                className="btn btn-primary w-100 p-2 mt-2 rounded-1"
              >
                Login
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
