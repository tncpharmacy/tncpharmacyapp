declare module "pdfjs-dist/build/pdf";
declare module "pdfjs-dist/build/pdf.worker";
declare module "pdfjs-dist/build/pdf.worker.js";
declare module "pdfjs-dist/build/pdf.js";
